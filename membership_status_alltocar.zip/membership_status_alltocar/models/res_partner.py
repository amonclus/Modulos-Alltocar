from odoo import models, fields, api, _


class ResPartner(models.Model):
    _inherit = 'res.partner'
    membership_id = fields.Integer(
        string='Membership Id',
        tracking=True,
        readonly=True,
        help="This shows the points that the customer has accumulated",
    )





