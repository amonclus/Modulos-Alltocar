
odoo.define("membership_status.MembershipStatus", function(require){
    "use strict";
        const {Component, useState} = require("@odoo/owl")
        const PosComponent = require("point_of_sale.PosComponent");
        const ProductScreen = require("point_of_sale.ProductScreen");
        const Registries = require("point_of_sale.Registries");
        const {useListener} = require("@web/core/utils/hooks");
        //const MembershipField = require("/home/amonclus/odoo16/alltogo-addons/customer_membership_management/models/res_partner.py")

        class MembershipStatus extends PosComponent {
            setup() {
                console.log("0")
                super.setup();
                this.state = useState({ membershipActive: null, error: null, partnerId:null })

                const order = this.env.pos.get_order()
                const partner = order.get_partner()
                this.state.partnerId = partner.id

                this.fetchMembershipStatus()
                console.log("2")
            }

            async fetchMembershipStatus() {
                try {
                    console.log("Fetching membership status for partner ID:", this.state.partnerId); // Add this line
                    console.log("1")
                    const result = await this._rpc({
                        route: '/get_membership_status',
                        params: {
                            'partner_id': this.state.partnerId
                        }
                    });
                    //No llega aqui
                    console.log("3")
                    if (result.error) {
                        this.state.error = result.error
                    } else {
                        this.state.membershipActive = result.membership_active
                        console.log(this.state.membershipActive)
                    }
                } catch (error) {
                    this.state.error = 'Failed to fetch membership status'
                }
            }

            get isActive() {
                return !!this.state.membershipActive;
            }
        }


        MembershipStatus.template = "owl.MembershipStatus"
        

        ProductScreen.addControlButton({
            component: MembershipStatus,
            position: ["before" , "SetSaleOrderButton"],
        });

        Registries.Component.add(MembershipStatus)
    
        return MembershipStatus
    });

